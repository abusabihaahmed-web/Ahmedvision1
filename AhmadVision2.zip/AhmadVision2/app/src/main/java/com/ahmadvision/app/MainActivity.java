package com.ahmadvision.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import org.json.JSONObject;
import java.net.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(5,11,24), PANEL=Color.rgb(11,24,46), BLUE=Color.rgb(25,167,255);
    private LinearLayout root, content;
    private EditText server,user,pass,m3u;
    private TextView status;
    private String activeTab="الرئيسية";

    @Override public void onCreate(Bundle b){ super.onCreate(b); showHome(); }

    private GradientDrawable shape(int color,int radius,int stroke){
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius);
        if(stroke>0)d.setStroke(2,stroke); return d;
    }
    private TextView label(String s,int size,int color,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private LinearLayout column(){
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private LinearLayout row(){
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private void base(String title){
        root=column(); root.setBackgroundColor(BG);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout page=column(); page.setPadding(22,22,22,28);
        TextView brand=label("AHMAD  VISION",18,BLUE,true);
        page.addView(brand,new LinearLayout.LayoutParams(-1,34));
        TextView heading=label(title,27,Color.WHITE,true);
        page.addView(heading,new LinearLayout.LayoutParams(-1,58));
        content=column(); page.addView(content);
        scroll.addView(page); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        LinearLayout nav=row(); nav.setPadding(10,8,10,8); nav.setBackgroundColor(PANEL);
        String[] tabs={"الرئيسية","بث مباشر","أفلام","مسلسلات","المفضلة"};
        for(String tab:tabs){
            TextView t=label(tab,12,tab.equals(activeTab)?BLUE:Color.LTGRAY,true); t.setGravity(Gravity.CENTER);
            nav.addView(t,new LinearLayout.LayoutParams(0,48,1));
            t.setFocusable(true); t.setOnClickListener(v->{activeTab=tab; showTab(tab);});
        }
        root.addView(nav);
    }
    private void card(String title,String subtitle,String action,Runnable click){
        LinearLayout c=column(); c.setPadding(16,14,16,14); c.setBackground(shape(PANEL,20,Color.rgb(22,55,91)));
        TextView h=label(title,18,Color.WHITE,true); c.addView(h);
        TextView sub=label(subtitle,13,Color.LTGRAY,false); c.addView(sub);
        if(action!=null){ TextView a=label(action+"  ›",14,BLUE,true); a.setPadding(0,12,0,0); c.addView(a); c.setOnClickListener(v->click.run()); c.setFocusable(true); }
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=12; content.addView(c,p);
    }
    private void showHome(){
        activeTab="الرئيسية"; base("مشاهدة بلا حدود");
        TextView intro=label("ترفيهك المفضل، بتجربة أكثر أناقة.",15,Color.LTGRAY,false);
        content.addView(intro); space(18);
        card("▶  LIVE TV","تابع قنواتك المباشرة","فتح القنوات",()->showTab("بث مباشر"));
        card("▣  MOVIES","اكتشف مكتبة الأفلام","عرض الأفلام",()->showTab("أفلام"));
        card("▤  SERIES","تابع مسلسلاتك","عرض المسلسلات",()->showTab("مسلسلات"));
        card("★  FAVORITES","كل ما تحبه في مكان واحد","المفضلة",()->showTab("المفضلة"));
        card("إعداد الاشتراك","أضف بيانات Xtream Codes أو رابط M3U","إعداد الآن",()->showSetup());
    }
    private void showTab(String tab){
        activeTab=tab; base(tab);
        if(tab.equals("الرئيسية")){showHome();return;}
        if(tab.equals("بث مباشر")) card("القنوات المباشرة","أضف اشتراكك من الإعدادات لعرض القنوات.","إعداد الاشتراك",()->showSetup());
        else if(tab.equals("أفلام")) card("مكتبة الأفلام","ستظهر الأفلام المتاحة ضمن اشتراكك هنا.","إعداد الاشتراك",()->showSetup());
        else if(tab.equals("مسلسلات")) card("المسلسلات","ستظهر المسلسلات والحلقات ضمن اشتراكك هنا.","إعداد الاشتراك",()->showSetup());
        else card("المفضلة","احفظ قنواتك ومحتواك المفضل للوصول السريع.","العودة للرئيسية",()->showHome());
    }
    private void space(int h){ View v=new View(this); content.addView(v,new LinearLayout.LayoutParams(1,h)); }
    private EditText field(String hint){
        EditText e=new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setHintTextColor(Color.GRAY); e.setTextColor(Color.WHITE);
        e.setPadding(14,10,14,10); e.setBackground(shape(Color.rgb(8,18,35),12,Color.rgb(30,76,120)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,52); p.bottomMargin=10; content.addView(e,p); return e;
    }
    private void showSetup(){
        activeTab="الرئيسية"; base("إعداد الاشتراك");
        TextView note=label("أدخل بيانات مزوّد الخدمة الذي تملك اشتراكاً لديه.",14,Color.LTGRAY,false); content.addView(note); space(14);
        TextView sub=label("XTREAM CODES",13,BLUE,true); content.addView(sub); space(8);
        server=field("رابط السيرفر مثال https://example.com");
        user=field("اسم المستخدم"); pass=field("كلمة المرور"); pass.setInputType(129);
        Button connect=button("اتصال عبر Xtream Codes"); content.addView(connect); connect.setOnClickListener(v->connectXtream());
        space(18); TextView or=label("— أو استخدم رابط M3U —",13,Color.LTGRAY,false); or.setGravity(Gravity.CENTER); content.addView(or); space(10);
        m3u=field("رابط قائمة M3U"); Button m=button("حفظ رابط M3U"); content.addView(m);
        m.setOnClickListener(v->{String url=m3u.getText().toString().trim(); if(url.startsWith("http")){saveStatus("تم إدخال رابط M3U. سيتم تحميل القنوات عند تفعيل وحدة التشغيل.");}else saveStatus("تحقق من رابط M3U.");});
        status=label("",13,BLUE,false); status.setPadding(0,14,0,0); content.addView(status);
        space(12); card("الخصوصية","بيانات الاشتراك تُستخدم للاتصال بالسيرفر الذي تدخله فقط. لا يتضمن التطبيق قنوات أو اشتراكات جاهزة.",null,null);
    }
    private Button button(String text){
        Button b=new Button(this); b.setText(text); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setBackground(shape(BLUE,14,0)); b.setPadding(12,6,12,6);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,52); p.bottomMargin=8; b.setLayoutParams(p); return b;
    }
    private void saveStatus(String s){ if(status!=null)status.setText(s); }
    private void connectXtream(){
        final String s=server.getText().toString().trim(), u=user.getText().toString().trim(), p=pass.getText().toString();
        if(s.isEmpty()||u.isEmpty()||p.isEmpty()){saveStatus("أكمل رابط السيرفر واسم المستخدم وكلمة المرور.");return;}
        saveStatus("جارٍ التحقق من بيانات الاتصال…");
        new Thread(()->{
            String result;
            try{
                String base=s.replaceAll("/+$","");
                URL url=new URL(base+"/player_api.php?username="+URLEncoder.encode(u,"UTF-8")+"&password="+URLEncoder.encode(p,"UTF-8"));
                HttpURLConnection c=(HttpURLConnection)url.openConnection(); c.setConnectTimeout(10000); c.setReadTimeout(10000); c.setRequestMethod("GET");
                InputStream in=(c.getResponseCode()<400)?c.getInputStream():c.getErrorStream();
                ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buf=new byte[4096]; int n;
                while((n=in.read(buf))!=-1)out.write(buf,0,n);
                JSONObject json=new JSONObject(out.toString("UTF-8"));
                JSONObject info=json.optJSONObject("user_info");
                result=(info!=null && info.optString("auth","0").equals("1"))?"تم الاتصال بالسيرفر بنجاح.":"لم يتم قبول بيانات الدخول. تحقق منها ومن عنوان السيرفر.";
                c.disconnect();
            }catch(Exception e){result="تعذّر الاتصال. تحقق من الرابط والإنترنت وبيانات الاشتراك.";}
            final String msg=result; runOnUiThread(()->saveStatus(msg));
        }).start();
    }
}
